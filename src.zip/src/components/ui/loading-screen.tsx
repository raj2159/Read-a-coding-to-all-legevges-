
import React from 'react';

const CarIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-32 h-32 text-white">
    <path d="M18.92 6.01C18.72 5.42 18.16 5 17.5 5h-11C5.84 5 5.28 5.42 5.08 6.01L3 12v8c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h12v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-8l-2.08-5.99zM6.5 16c-.83 0-1.5-.67-1.5-1.5S5.67 13 6.5 13s1.5.67 1.5 1.5S7.33 16 6.5 16zm11 0c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zM5 11l1.5-4.5h11L19 11H5z" data-ai-hint="car" />
  </svg>
);

export const LoadingScreen = () => {
  return (
    <div className="fixed inset-0 bg-gray-900 z-50 flex flex-col items-center justify-center overflow-hidden">
      <style>
        {`
          @keyframes drift {
            0% { transform: translateX(-150px) rotate(-8deg); }
            50% { transform: translateX(150px) rotate(8deg); }
            100% { transform: translateX(-150px) rotate(-8deg); }
          }
          .drifting-car {
            animation: drift 3s ease-in-out infinite;
          }
          
          @keyframes pulse-text {
            0%, 100% {
              opacity: 1;
            }
            50% {
              opacity: 0.5;
            }
          }
           .loading-text {
            animation: pulse-text 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
           }
        `}
      </style>
      <div className="drifting-car mb-4">
        <CarIcon />
      </div>
      <p className="loading-text text-white text-2xl font-bold" data-ai-hint="loading text">Make by raj gagiya</p>
    </div>
  );
};
