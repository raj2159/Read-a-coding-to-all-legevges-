import type { SVGProps } from "react";

export function JavascriptIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="1em"
      height="1em"
      viewBox="0 0 24 24"
      {...props}
    >
      <path
        fill="currentColor"
        d="M12 12H6v-2h6v-2H6V6h8v12h-2v-4h-2v4H6V6h2v4h4zm6-6h-4v12h4V6zm-2 10v-2h2v2zm0-4v-2h2v2zm0-4V8h2v2z"
      ></path>
    </svg>
  );
}
