import type { SVGProps } from "react";

export function PythonIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="1em"
      height="1em"
      viewBox="0 0 24 24"
      {...props}
    >
      <path
        fill="currentColor"
        d="M21 9h-4V7a2 2 0 0 1 2-2h2zm-4 4v2h4v-2zM3 15h4v2a2 2 0 0 1-2 2H3zm4-4V9H3v2zm11-6v10a2 2 0 0 1-2 2H7v-4h4a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2H7V5a2 2 0 0 1 2-2h9z"
      ></path>
    </svg>
  );
}
