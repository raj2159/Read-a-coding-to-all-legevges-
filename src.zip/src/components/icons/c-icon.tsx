import type { SVGProps } from "react";

export function CIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="1em"
      height="1em"
      viewBox="0 0 24 24"
      {...props}
    >
      <path
        fill="currentColor"
        d="M10.033 14.39q-1.149 0-1.85-.715q-.7-.715-.7-1.89q0-1.174.7-1.89q.7-.715 1.85-.715q1.149 0 1.85.715q.7.716.7 1.89q0 1.175-.7 1.89q-.7.715-1.85.715m0-1.28q.61 0 .942-.423q.333-.423.333-1.187q0-.764-.333-1.187q-.332-.423-.942-.423q-.61 0-.942.423q-.333.423-.333 1.187q0 .764.333 1.187q.332.423.942.423"
      ></path>
    </svg>
  );
}
