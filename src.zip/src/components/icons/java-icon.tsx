import type { SVGProps } from "react";

export function JavaIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="1em"
      height="1em"
      viewBox="0 0 24 24"
      {...props}
    >
      <path
        fill="currentColor"
        d="M4 21q-.825 0-1.412-.587T2 19V5q0-.825.588-1.412T4 3h16q.825 0 1.413.588T22 5v14q0 .825-.587 1.413T20 21zm4-13h6V6H8zm0 2v3q0 .825.588 1.413T10 15h2v-2h-2v-1h4v3q0 .825-.587 1.413T12 18h-2q-1.65 0-2.825-1.175T6 14v-3z"
      ></path>
    </svg>
  );
}
