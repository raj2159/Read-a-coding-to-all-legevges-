'use server';

/**
 * @fileOverview An AI agent to generate quiz questions.
 *
 * - generateQuizQuestion - A function that generates a single quiz question.
 * - GenerateQuizQuestionInput - The input type for the generateQuizQuestion function.
 * - GenerateQuizQuestionOutput - The return type for the generateQuizQuestion function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateQuizQuestionInputSchema = z.object({
  topic: z.string().describe('The topic for the quiz question (e.g., Data Structures, JavaScript, Python).'),
  skillLevel: z.string().describe("The user's skill level (e.g., Beginner, Intermediate, Advanced)."),
});
export type GenerateQuizQuestionInput = z.infer<typeof GenerateQuizQuestionInputSchema>;

const GenerateQuizQuestionOutputSchema = z.object({
    id: z.string().describe("A unique ID for the question."),
    text: z.string().describe("The interview question."),
    options: z.array(z.object({
        id: z.string().describe("A unique ID for this option."),
        text: z.string().describe("The text for this option.")
    })).describe("A list of 3-4 multiple choice options."),
    correctOptionId: z.string().describe("The ID of the correct option."),
});
export type GenerateQuizQuestionOutput = z.infer<typeof GenerateQuizQuestionOutputSchema>;

export async function generateQuizQuestion(
  input: GenerateQuizQuestionInput
): Promise<GenerateQuizQuestionOutput> {
  return generateQuizQuestionFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateQuizQuestionPrompt',
  input: {schema: GenerateQuizQuestionInputSchema},
  output: {schema: GenerateQuizQuestionOutputSchema},
  prompt: `You are an expert-level interviewer for a top tech company. Your role is to generate a single technical quiz question to help a candidate prepare.

  The question should be based on the provided topic and the user's skill level. It should be a multiple-choice question with 3 or 4 options. You must provide the correct answer. Make sure the options are plausible but only one is correct.

  Topic: {{{topic}}}
  Skill Level: {{{skillLevel}}}

  Generate one question appropriate for the user's skill level.
  `,
});

const generateQuizQuestionFlow = ai.defineFlow(
  {
    name: 'generateQuizQuestionFlow',
    inputSchema: GenerateQuizQuestionInputSchema,
    outputSchema: GenerateQuizQuestionOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
