'use server';

/**
 * @fileOverview An AI agent to generate personalized daily tasks based on user progress and skill level.
 *
 * - generatePersonalizedTasks - A function that generates personalized tasks.
 * - GeneratePersonalizedTasksInput - The input type for the generatePersonalizedTasks function.
 * - GeneratePersonalizedTasksOutput - The return type for the generatePersonalizedTasks function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GeneratePersonalizedTasksInputSchema = z.object({
  userSkills: z
    .array(z.string())
    .describe('A list of the users current skills.'),
  userProgress: z.string().describe('A description of the users progress.'),
  preferredLanguages: z
    .array(z.string())
    .describe('The users preferred programming languages.'),
  toolsAvailable: z
    .array(z.string())
    .describe('The tools available to the user (e.g. compiler, IDE).'),
});
export type GeneratePersonalizedTasksInput = z.infer<typeof GeneratePersonalizedTasksInputSchema>;

const GeneratePersonalizedTasksOutputSchema = z.object({
  tasks: z.array(z.object({
    title: z.string().describe("A short, clear title for the task."),
    description: z.string().describe("A step-by-step guide on how to complete the task."),
    objective: z.string().describe("What the user will learn by completing this task.")
  })).describe('A list of personalized tasks for the user.'),
});
export type GeneratePersonalizedTasksOutput = z.infer<typeof GeneratePersonalizedTasksOutputSchema>;

export async function generatePersonalizedTasks(
  input: GeneratePersonalizedTasksInput
): Promise<GeneratePersonalizedTasksOutput> {
  return generatePersonalizedTasksFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generatePersonalizedTasksPrompt',
  input: {schema: GeneratePersonalizedTasksInputSchema},
  output: {schema: GeneratePersonalizedTasksOutputSchema},
  prompt: `You are an AI task generator that creates personalized daily tasks for users based on their progress and skill level in programming.

  Consider the user's current skills, progress, preferred languages, and available tools to generate relevant and challenging tasks. Generate tasks which are suited for the users growth, by addressing their weaknesses with the available tools. For each task, provide a clear title, a step-by-step description, and a learning objective.

  Current Skills: {{#if userSkills}}{{#each userSkills}}- {{{this}}}
{{/each}}{{else}}No skills listed.{{/if}}

  User Progress: {{{userProgress}}}

  Preferred Languages: {{#if preferredLanguages}}{{#each preferredLanguages}}- {{{this}}}
{{/each}}{{else}}No preferred languages listed.{{/if}}

  Available Tools: {{#if toolsAvailable}}{{#each toolsAvailable}}- {{{this}}}
{{/each}}{{else}}No tools listed.{{/if}}

  Generate a list of 3 tasks that will help the user improve their skills.
  `,
});

const generatePersonalizedTasksFlow = ai.defineFlow(
  {
    name: 'generatePersonalizedTasksFlow',
    inputSchema: GeneratePersonalizedTasksInputSchema,
    outputSchema: GeneratePersonalizedTasksOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
