
'use server';
/**
 * @fileOverview An AI agent for searching content within the application.
 *
 * - searchContent - A function that performs a search.
 * - SearchContentInput - The input type for the searchContent function.
 * - SearchContentOutput - The return type for the searchContent function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';
import { courses } from '@/lib/data';

// Generate a searchable index from the courses data
const searchableContent = courses.flatMap(course => 
  course.modules.map(module => ({
    id: `${course.id}-${module.id}`,
    title: `${course.title}: ${module.title}`,
    content: module.content.replace(/<[^>]*>?/gm, ''), // Remove HTML tags
    url: `/courses/${course.id}`
  }))
);

const SearchContentInputSchema = z.object({
  query: z.string().describe('The search query from the user.'),
});
export type SearchContentInput = z.infer<typeof SearchContentInputSchema>;

const SearchContentOutputSchema = z.object({
  results: z.array(
    z.object({
      title: z.string().describe('The title of the search result.'),
      snippet: z.string().describe('A brief snippet of the content.'),
      url: z.string().describe('The URL to the content.'),
    })
  ).describe('A list of relevant search results.'),
});
export type SearchContentOutput = z.infer<typeof SearchContentOutputSchema>;

export async function searchContent(input: SearchContentInput): Promise<SearchContentOutput> {
  return searchContentFlow(input);
}

const prompt = ai.definePrompt({
  name: 'searchContentPrompt',
  input: { schema: SearchContentInputSchema },
  output: { schema: SearchContentOutputSchema },
  prompt: `You are a helpful search assistant for a learning platform. Your task is to find the most relevant content based on the user's query.

Search Query: {{{query}}}

Available Content (JSON format):
\`\`\`json
{{{json content}}}
\`\`\`

Based on the query, return a list of up to 5 relevant results from the available content. For each result, provide the title, a concise snippet (max 30 words) that is relevant to the query, and the URL.
`,
});

const searchContentFlow = ai.defineFlow(
  {
    name: 'searchContentFlow',
    inputSchema: SearchContentInputSchema,
    outputSchema: SearchContentOutputSchema,
  },
  async (input) => {
    const { output } = await prompt({
        ...input,
        content: JSON.stringify(searchableContent),
    });
    return output!;
  }
);
