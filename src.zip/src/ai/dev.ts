import { config } from 'dotenv';
config();

import '@/ai/flows/generate-personalized-tasks.ts';
import '@/ai/flows/generate-quiz-questions.ts';
