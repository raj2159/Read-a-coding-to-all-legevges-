import { CIcon } from "@/components/icons/c-icon";
import { CPlusPlusIcon } from "@/components/icons/c-plus-plus-icon";
import { JavaIcon } from "@/components/icons/java-icon";
import { JavascriptIcon } from "@/components/icons/javascript-icon";
import { PythonIcon } from "@/components/icons/python-icon";

export interface Option {
  id: string;
  text: string;
}

export interface Question {
  id: string;
  text: string;
  options: Option[];
  correctOptionId: string;
}

export interface Quiz {
  title: string;
  questions: Question[];
}

export interface Module {
  id: string;
  title: string;
  content: string;
  quiz?: Quiz;
}

export interface Course {
    id: string;
    title: string;
    description: string;
    icon: React.ComponentType<any>;
    modules: Module[];
}


export const courses: Course[] = [
  {
    id: "html",
    title: "HTML",
    description: "Learn the foundation of web pages.",
    icon: JavascriptIcon, // Placeholder
    modules: [
      {
        id: "module-1",
        title: "Introduction to HTML",
        content: `
          <p>HTML (HyperText Markup Language) is the standard markup language for documents designed to be displayed in a web browser.</p>
          <p>Key concepts:</p>
          <ul>
            <li><strong>Tags:</strong> The building blocks of HTML (e.g., <code>&lt;p&gt;</code>, <code>&lt;h1&gt;</code>).</li>
            <li><strong>Elements:</strong> Consist of a start tag, content, and an end tag.</li>
            <li><strong>Attributes:</strong> Provide additional information about elements.</li>
          </ul>
        `,
        quiz: {
          title: "HTML Quiz",
          questions: [
            {
              id: "q1",
              text: "What does HTML stand for?",
              options: [
                { id: "opt1", text: "HyperText Markup Language" },
                { id: "opt2", text: "Home Tool Markup Language" },
                { id: "opt3", text: "Hyperlinks and Text Markup Language" },
              ],
              correctOptionId: "opt1",
            },
          ],
        },
      },
    ],
  },
  {
    id: "css",
    title: "CSS",
    description: "Style your web pages with CSS.",
    icon: JavascriptIcon, // Placeholder
    modules: [
      {
        id: "module-1",
        title: "Introduction to CSS",
        content: `
          <p>CSS (Cascading Style Sheets) is a style sheet language used for describing the presentation of a document written in a markup language like HTML.</p>
          <p>You'll learn about:</p>
          <ul>
            <li><strong>Selectors:</strong> To target HTML elements.</li>
            <li><strong>Properties:</strong> To style the elements (e.g., <code>color</code>, <code>font-size</code>).</li>
            <li><strong>The Box Model:</strong> Margin, border, padding, and content.</li>
          </ul>
        `,
        quiz: {
          title: "CSS Quiz",
          questions: [
            {
              id: "q1",
              text: "Which property is used to change the background color?",
              options: [
                { id: "opt1", text: "color" },
                { id: "opt2", text: "background-color" },
                { id: "opt3", text: "bgcolor" },
              ],
              correctOptionId: "opt2",
            },
          ],
        },
      },
    ],
  },
  {
    id: "js",
    title: "JavaScript",
    description: "Make your web pages interactive.",
    icon: JavascriptIcon,
    modules: [
       {
        id: "module-1",
        title: "Introduction to JavaScript",
        content: `
          <p>JavaScript is a programming language that enables you to create dynamically updating content, control multimedia, animate images, and much more.</p>
        `,
        quiz: {
          title: "JavaScript Quiz",
          questions: [
            {
              id: "q1",
              text: "How do you declare a constant variable in JS?",
              options: [
                { id: "opt1", text: "const" },
                { id: "opt2", text: "let" },
                { id: "opt3", text: "var" },
              ],
              correctOptionId: "opt1",
            },
          ],
        },
      },
    ],
  },
  {
    id: "python",
    title: "Python",
    description: "From fundamentals to advanced concepts in Python.",
    icon: PythonIcon,
    modules: [
      {
        id: "module-1",
        title: "Introduction to Python",
        content: `
          <p>Welcome to the world of Python! Python is a high-level, interpreted programming language known for its simple syntax and readability.</p>
          <p>In this module, you'll learn:</p>
          <ul>
            <li>What Python is and why it's so popular.</li>
            <li>How to install Python and set up your development environment.</li>
            <li>How to write and run your first Python script.</li>
          </ul>
          <pre><code class="language-python">print("Hello, World!")</code></pre>
        `,
        quiz: {
          title: "Module 1 Quiz",
          questions: [
            {
              id: "q1",
              text: "What is Python primarily known for?",
              options: [
                { id: "opt1", text: "Complex syntax" },
                { id: "opt2", text: "Readability and simple syntax" },
                { id: "opt3", text: "Being a low-level language" },
              ],
              correctOptionId: "opt2",
            },
             {
              id: "q2",
              text: "Which of the following is NOT a built-in data type in Python?",
              options: [
                { id: "opt1", text: "List" },
                { id: "opt2", text: "Array" },
                { id: "opt3", text: "Dictionary" },
              ],
              correctOptionId: "opt2",
            },
          ],
        },
      },
    ],
  },
  {
    id: "c",
    title: "C",
    description: "Master the basics of systems programming with C.",
    icon: CIcon,
    modules: [
      {
        id: "module-1",
        title: "C Basics",
        content: `
          <p>C is a powerful general-purpose programming language. It is fast, portable and has a rich library.</p>
        `,
        quiz: {
          title: "C Quiz",
          questions: [
            {
              id: "q1",
              text: "Which function is used to allocate memory in C?",
              options: [
                { id: "opt1", text: "malloc()" },
                { id: "opt2", text: "alloc()" },
                { id: "opt3", text: "new()" },
              ],
              correctOptionId: "opt1",
            },
          ],
        },
      },
    ],
  },
  {
    id: "cpp",
    title: "C++",
    description: "Explore the power and performance of C++.",
    icon: CPlusPlusIcon,
    modules: [
       {
        id: "module-1",
        title: "C++ Basics",
        content: `
          <p>C++ is a cross-platform language that can be used to create high-performance applications.</p>
        `,
        quiz: {
          title: "C++ Quiz",
          questions: [
            {
              id: "q1",
              text: "C++ is a superset of which language?",
              options: [
                { id: "opt1", text: "Python" },
                { id: "opt2", text: "C" },
                { id: "opt3", text: "Java" },
              ],
              correctOptionId: "opt2",
            },
          ],
        },
      },
    ],
  },
  {
    id: "java",
    title: "Java",
    description: "Learn the fundamentals of object-oriented programming with Java.",
    icon: JavaIcon,
    modules: [
       {
        id: "module-1",
        title: "Java Basics",
        content: `
          <p>Java is a high-level, class-based, object-oriented programming language that is designed to have as few implementation dependencies as possible.</p>
        `,
        quiz: {
          title: "Java Quiz",
          questions: [
            {
              id: "q1",
              text: "In Java, all classes inherit from which class?",
              options: [
                { id: "opt1", text: "Object" },
                { id: "opt2", text: "Class" },
                { id: "opt3", text: "Main" },
              ],
              correctOptionId: "opt1",
            },
          ],
        },
      },
    ],
  },
];

export const getCourseById = (id: string | undefined): Course | undefined => {
  if (!id) return undefined;
  return courses.find((course) => course.id === id);
};
