
'use client';

import { useState, useEffect } from 'react';
import { Bar } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';
import { courses, getCourseById, Course, Question } from '@/lib/data';
import { generateQuizQuestion, GenerateQuizQuestionOutput } from '@/ai/flows/generate-quiz-questions';
import { generatePersonalizedTasks, GeneratePersonalizedTasksOutput } from '@/ai/flows/generate-personalized-tasks';
import { LoadingScreen } from '@/components/ui/loading-screen';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const pages = ['home', 'html', 'css', 'js', 'python', 'c', 'cpp', 'java', 'progress', 'job-prep'];

type ProgressData = {
  [key: string]: number;
};

type QuizState = {
  [key: string]: {
    showFeedback: boolean;
    isCorrect: boolean | null;
    selectedOptionId: string | null;
    question: Question | null;
    generatingQuestion: boolean;
    skillLevel: 'Beginner' | 'Intermediate' | 'Advanced';
  };
};

type DailyTasksState = {
  tasks: { title: string; description: string; objective: string; }[];
  generating: boolean;
}

export default function UltimateSWELearningHub() {
  const [currentPage, setCurrentPage] = useState('home');
  const [progressData, setProgressData] = useState<ProgressData>({});
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [quizState, setQuizState] = useState<QuizState>({});
  const [dailyTasksState, setDailyTasksState] = useState<DailyTasksState>({ tasks: [], generating: false });
  const [appLoading, setAppLoading] = useState(true);

  useEffect(() => {
    const savedProgress = localStorage.getItem('progressData');
    if (savedProgress) {
      setProgressData(JSON.parse(savedProgress));
    } else {
      const initialProgress = courses.reduce((acc, course) => {
        acc[course.id] = 0;
        return acc;
      }, {} as ProgressData);
      setProgressData(initialProgress);
    }

    const initialQuizState = courses.reduce((acc, course) => {
      acc[course.id] = {
        showFeedback: false,
        isCorrect: null,
        selectedOptionId: null,
        question: null, 
        generatingQuestion: false,
        skillLevel: 'Beginner',
      };
      return acc;
    }, {} as QuizState);
    setQuizState(initialQuizState);
    
    setAppLoading(false);

  }, []);

  const showPage = (page: string) => {
    setCurrentPage(page);
  };

  const handleOptionSelect = (subject: string, optionId: string) => {
    if (quizState[subject]?.showFeedback) return;

    setQuizState(prev => ({
      ...prev,
      [subject]: {
        ...prev[subject],
        selectedOptionId: optionId,
      }
    }));
  };

  const checkQuiz = (subject: string) => {
    const state = quizState[subject];
    if (!state || state.selectedOptionId === null || !state.question) return;
    
    const correct = state.question.correctOptionId === state.selectedOptionId;

    let newSkillLevel = state.skillLevel;
    if (correct) {
      if (state.skillLevel === 'Beginner') newSkillLevel = 'Intermediate';
      else if (state.skillLevel === 'Intermediate') newSkillLevel = 'Advanced';
    }

    setQuizState(prev => ({
      ...prev,
      [subject]: {
        ...prev[subject],
        showFeedback: true,
        isCorrect: correct,
        skillLevel: newSkillLevel,
      }
    }));

    if (correct) {
      const newProgress = {
        ...progressData,
        [subject]: Math.min(progressData[subject] + 10, 100),
      };
      setProgressData(newProgress);
      localStorage.setItem('progressData', JSON.stringify(newProgress));
    }
  };

  const handleGenerateQuestion = async (courseId: string) => {
    const course = getCourseById(courseId);
    const state = quizState[courseId];
    if (!course || !state) return;

    setQuizState(prev => ({
      ...prev,
      [courseId]: { ...prev[courseId], generatingQuestion: true }
    }));

    try {
      const newQuestion: GenerateQuizQuestionOutput = await generateQuizQuestion({ 
        topic: course.title,
        skillLevel: state.skillLevel,
      });
      setQuizState(prev => {
        return {
          ...prev,
          [courseId]: {
            ...prev[courseId],
            question: newQuestion,
            showFeedback: false,
            isCorrect: null,
            selectedOptionId: null,
            generatingQuestion: false,
          }
        };
      });
    } catch (error) {
      console.error("Failed to generate question:", error);
      alert("Sorry, we couldn't generate a new question right now. Please try again later.");
      setQuizState(prev => ({
        ...prev,
        [courseId]: { ...prev[courseId], generatingQuestion: false }
      }));
    }
  };

  const handleGenerateDailyTasks = async () => {
    setDailyTasksState({ ...dailyTasksState, generating: true });

    const userSkills = Object.entries(progressData)
      .filter(([, progress]) => progress > 20)
      .map(([skill]) => getCourseById(skill)?.title || skill);

    const userProgress = `The user has the following progress in various subjects: ${JSON.stringify(progressData)}. They are generally at a beginner to intermediate level.`;

    try {
        const result = await generatePersonalizedTasks({
            userSkills,
            userProgress,
            preferredLanguages: ["JavaScript", "Python"],
            toolsAvailable: ["Online IDE", "Browser DevTools"],
        });
        setDailyTasksState({ tasks: result.tasks, generating: false });
    } catch (error) {
        console.error("Failed to generate tasks:", error);
        alert("Sorry, we couldn't generate your personalized tasks right now. Please try again later.");
        setDailyTasksState({ ...dailyTasksState, generating: false });
    }
  };
  
  const toggleMode = () => {
    setIsDarkMode(!isDarkMode);
    document.body.classList.toggle('dark-mode');
  }

  const chartData = {
    labels: Object.keys(progressData),
    datasets: [
      {
        label: 'Progress %',
        data: Object.values(progressData),
        backgroundColor: 'rgba(76, 175, 80, 0.5)',
        borderColor: 'rgba(76, 175, 80, 1)',
        borderWidth: 1,
      },
    ],
  };
  
  const chartOptions = {
    responsive: true,
    scales: {
      y: {
        beginAtZero: true,
        max: 100,
        ticks: {
          color: isDarkMode ? '#f9f9f9' : '#222',
        },
        grid: {
            color: isDarkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)',
        }
      },
      x: {
        ticks: {
            color: isDarkMode ? '#f9f9f9' : '#222',
        },
        grid: {
            color: isDarkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)',
        }
      }
    },
    plugins: {
        legend: {
            labels: {
                color: isDarkMode ? '#f9f9f9' : '#222',
            }
        }
    }
  };
  
  const renderQuiz = (courseId: string) => {
    const course = getCourseById(courseId);
    const state = quizState[courseId];

    if (!course || !state) {
      return <p>Loading quiz...</p>;
    }

    const question = state.question;

    const renderQuestion = () => {
        if (!question) {
            return (
              <div>
                <p>Click the button to start the quiz!</p>
              </div>
            );
        }

        const getButtonClass = (optionId: string) => {
            if (!state.showFeedback) {
                return state.selectedOptionId === optionId ? 'selected' : '';
            }
            if (question.correctOptionId === optionId) {
                return 'correct';
            }
            if (state.selectedOptionId === optionId) {
                return 'incorrect';
            }
            return 'disabled';
        };

        return (
            <div className="quiz-content">
                <p>Q: {question.text}</p>
                <div className="quiz-options">
                    {question.options.map(option => (
                        <button
                            key={option.id}
                            onClick={() => handleOptionSelect(courseId, option.id)}
                            className={getButtonClass(option.id)}
                            disabled={state.showFeedback}
                        >
                            {option.text}
                        </button>
                    ))}
                </div>
                {state.showFeedback && (
                    <div className={`feedback ${state.isCorrect ? 'correct' : 'incorrect'}`}>
                        <p>{state.isCorrect ? 'Correct!' : 'Incorrect. The correct answer is highlighted.'}</p>
                    </div>
                )}
                {!state.showFeedback && (
                    <button onClick={() => checkQuiz(courseId)} disabled={state.selectedOptionId === null}>Check Answer</button>
                )}
            </div>
        );
    }
    
    return (
      <div className="quiz">
        <div className="quiz-header">
            <h3>Quiz</h3>
            <span className="skill-level">Level: {state.skillLevel}</span>
        </div>
        {renderQuestion()}
        <div className="quiz-controls mt-4">
            <button onClick={() => handleGenerateQuestion(courseId)} disabled={state.generatingQuestion}>
                {state.generatingQuestion ? 'Generating...' : 'Generate New Question' }
            </button>
        </div>
      </div>
    );
  };
  
  if (appLoading) {
    return <LoadingScreen />;
  }

  return (
    <div className={isDarkMode ? 'dark-mode' : ''}>
      <style jsx global>{`
        * { margin:0; padding:0; box-sizing:border-box; font-family: Arial, sans-serif; }
        body { background:#f9f9f9; color:#222; transition: background 0.3s, color 0.3s; }
        .dark-mode { background:#222; color:#f9f9f9; }
        .dark-mode .task, .dark-mode .module-content, .dark-mode .roadmap-step, .dark-mode .daily-task-card { background: #444; color: #f1f1f1; border-color: #555; }
        .dark-mode .quiz button { background: #388E3C; }
        .dark-mode .quiz button:disabled { background: #555; color: #aaa; cursor: not-allowed; }
        .dark-mode ul { color: #f9f9f9; }
        .dark-mode header { background: #388E3C; }
        header { background:#4CAF50; color:white; padding:10px; text-align:center; font-size:20px; }
        nav { display:flex; flex-wrap:wrap; background:#333; }
        nav button { flex:1; padding:10px; background:#444; color:white; border:none; cursor:pointer; min-width: 80px; transition: background 0.2s; }
        nav button:hover { background:#555; }
        nav button.active { background: #4CAF50; }
        .container { padding:20px; }
        .hidden { display:none; }
        .chart { width:100%; height:200px; }
        .task-list { margin-top:10px; }
        .task { padding:8px; background:#ddd; margin:5px 0; border-radius:5px; border: 1px solid #ccc; }
        .module-content { padding: 15px; margin: 10px 0; border-radius: 5px; border: 1px solid #ccc; }
        .module-content h3 { margin-bottom: 10px; }
        .module-content pre { background: #eee; padding: 10px; border-radius: 5px; margin: 10px 0; }
        .dark-mode .module-content pre { background: #333; }
        .quiz { margin-top:20px; padding: 15px; border-top: 1px solid #eee; }
        .quiz-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
        .quiz-header h3 { margin: 0; }
        .skill-level { font-size: 0.9em; font-weight: bold; background: #eee; padding: 2px 8px; border-radius: 10px; }
        .dark-mode .skill-level { background: #555; }
        .quiz p { font-weight: bold; margin-bottom: 10px; }
        .quiz-options { display: flex; flex-direction: column; gap: 10px; margin-bottom: 15px; }
        .quiz button, .quiz .feedback button { margin-top:10px; padding:8px 12px; background:#4CAF50; color:#fff; border:none; cursor:pointer; border-radius:5px; margin-right: 10px; transition: background 0.2s; }
        .quiz button:disabled { background: #aaa; cursor: not-allowed; }
        .quiz-options button { text-align: left; background: #eee; color: #333 }
        .dark-mode .quiz-options button { background: #555; color: #f1f1f1 }
        .quiz-options button.selected { border: 2px solid #4CAF50; }
        .quiz-options button.correct { background: #4CAF50; color: white; border-color: #388E3C; }
        .quiz-options button.incorrect { background: #f44336; color: white; border-color: #d32f2f; }
        .quiz-options button.disabled { color: #999; border-color: #ccc; cursor: not-allowed; opacity: 0.7; }
        .dark-mode .quiz-options button.disabled { color: #777; border-color: #555; }
        .feedback { margin-top: 10px; padding: 10px; border-radius: 5px; }
        .feedback.correct { border: 1px solid #4CAF50; background-color: #e8f5e9; color: #2e7d32; }
        .feedback.incorrect { border: 1px solid #f44336; background-color: #ffebee; color: #c62828; }
        .dark-mode .feedback.correct { background-color: #1c3d1e; color: #a5d6a7; }
        .dark-mode .feedback.incorrect { background-color: #4d1a1a; color: #ef9a9a; }
        .toggle-mode { position:fixed; top:10px; right:10px; background:#000; color:#fff; padding:6px; border-radius:6px; cursor:pointer; z-index: 1000; border: 1px solid #fff}
        ul { list-style-position: inside; color: #333; }
        .mt-4 { margin-top: 1rem; }
        .roadmap-step { padding: 15px; margin: 15px 0; border: 1px solid #ccc; border-radius: 8px; }
        .roadmap-step h3 { font-size: 1.5em; margin-bottom: 10px; color: #4CAF50; }
        .roadmap-step p { margin-bottom: 10px; }
        .roadmap-step ul { list-style-type: disc; padding-left: 20px; }
        .roadmap-step li { margin-bottom: 5px; }
        .ready-button { display: block; width: 100%; padding: 15px; font-size: 1.2em; background-color: #4CAF50; color: white; border: none; border-radius: 8px; cursor: pointer; margin-top: 20px; transition: background-color 0.3s; }
        .ready-button:hover { background-color: #45a049; }
        .ready-button:disabled { background-color: #aaa; cursor: not-allowed; }
        .daily-tasks-container { margin-top: 20px; }
        .daily-task-card { border: 1px solid #ccc; padding: 15px; margin-bottom: 15px; border-radius: 8px; }
        .daily-task-card h4 { font-size: 1.2em; color: #4CAF50; margin-bottom: 10px; }
        .daily-task-card p { margin-bottom: 10px; }
        .daily-task-card strong { font-weight: bold; }
      `}</style>

      <header>🚀 Ultimate SWE Learning Hub</header>
      <div className="toggle-mode" onClick={toggleMode}>{isDarkMode ? '☀️' : '🌓'}</div>

      <nav>
        <button onClick={() => showPage('home')} className={currentPage === 'home' ? 'active' : ''}>Home</button>
        {courses.map(course => (
          <button key={course.id} onClick={() => showPage(course.id)} className={currentPage === course.id ? 'active' : ''}>
            {course.title}
          </button>
        ))}
        <button onClick={() => showPage('progress')} className={currentPage === 'progress' ? 'active' : ''}>Progress</button>
        <button onClick={() => showPage('job-prep')} className={currentPage === 'job-prep' ? 'active' : ''}>Job Prep</button>
      </nav>

      <div className="container">
        <section id="home" className={currentPage === 'home' ? '' : 'hidden'}>
          <h2>Welcome to SWE Learning Hub</h2>
          <p>Here’s what you will learn step-by-step:</p>
          <ul>
            <li>✔ HTML, CSS, and Responsive Web Design</li>
            <li>✔ JavaScript and Advanced Frontend</li>
            <li>✔ Python and Data Structures</li>
            <li>✔ C, C++, and Java Programming</li>
            <li>✔ Mock Exams & Daily Tasks</li>
            <li>✔ Roadmap for Google SWE Interview</li>
          </ul>
        </section>
        
        {courses.map(course => (
          <section key={course.id} id={course.id} className={currentPage === course.id ? '' : 'hidden'}>
            <h2>{course.title}</h2>
            {course.modules.map(module => (
              <div key={module.id}>
                 <div className="module-content" dangerouslySetInnerHTML={{ __html: `<h3>${module.title}</h3>` + module.content }} />
              </div>
            ))}
            {quizState[course.id]?.question ? renderQuiz(course.id) : (
                 <div className="quiz-controls mt-4">
                    <button onClick={() => handleGenerateQuestion(course.id)} disabled={quizState[course.id]?.generatingQuestion}>
                        {quizState[course.id]?.generatingQuestion ? 'Generating...' : 'Start Quiz' }
                    </button>
                </div>
            )}
          </section>
        ))}

        <section id="progress" className={currentPage === 'progress' ? '' : 'hidden'}>
          <h2>Your Growth Chart</h2>
          <div className="chart">
            {currentPage === 'progress' && progressData && Object.keys(progressData).length > 0 && <Bar data={chartData} options={chartOptions} />}
          </div>
        </section>

        <section id="job-prep" className={currentPage === 'job-prep' ? '' : 'hidden'}>
          <h2>Google SWE Job Preparation Roadmap</h2>
          
          <div className="roadmap-step">
            <h3>Step 1: Master a Programming Language (1-2 Months)</h3>
            <p>Choose one language and become proficient in it. Google primarily uses C++, Java, and Python for interviews. Focus on understanding its core concepts, data structures, and standard libraries.</p>
            <p><strong>Focus Areas:</strong></p>
            <ul>
              <li>Variables, data types, and operators.</li>
              <li>Control flow (if/else, loops).</li>
              <li>Functions and recursion.</li>
              <li>Object-Oriented Programming (OOP) concepts if applicable (Classes, Objects, Inheritance).</li>
              <li>Standard library usage (e.g., Python's collections, C++ STL).</li>
            </ul>
          </div>

          <div className="roadmap-step">
            <h3>Step 2: Learn Data Structures & Algorithms (DSA) (3-4 Months)</h3>
            <p>This is the most critical part of the preparation. You need a deep understanding of DSA and the ability to apply them to solve problems.</p>
            <p><strong>Key Data Structures:</strong></p>
            <ul>
              <li>Arrays & Strings</li>
              <li>Linked Lists (Singly & Doubly)</li>
              <li>Stacks & Queues</li>
              <li>Hash Tables (Hash Maps, Hash Sets)</li>
              <li>Trees (Binary Trees, BSTs, Tries)</li>
              <li>Heaps (Min-Heap, Max-Heap)</li>
              <li>Graphs (DFS, BFS, Dijkstra's, Union-Find)</li>
            </ul>
            <p><strong>Key Algorithms:</strong></p>
            <ul>
                <li>Sorting (Mergesort, Quicksort) & Searching (Binary Search)</li>
                <li>Recursion and Backtracking</li>
                <li>Dynamic Programming</li>
                <li>Greedy Algorithms</li>
                <li>Graph Traversal and Shortest Path</li>
            </ul>
            <p><strong>Resources:</strong> LeetCode (start with Easy, move to Medium, then Hard), Cracking the Coding Interview book.</p>
          </div>

          <div className="roadmap-step">
            <h3>Step 3: Practice Problem Solving (Consistent Effort)</h3>
            <p>Solve a variety of problems on platforms like LeetCode. Aim for consistency over quantity. It's better to understand 2-3 problems deeply than to rush through 10.</p>
            <ul>
              <li><strong>Daily Practice:</strong> Aim to solve at least 1-2 problems daily.</li>
              <li><strong>Analyze Solutions:</strong> If you're stuck, look at the solution and try to understand the logic. Then, try to code it yourself without looking.</li>
              <li><strong>Time Yourself:</strong> Practice coding under time constraints (e.g., 45 minutes per problem) to simulate interview conditions.</li>
            </ul>
          </div>
          
          <div className="roadmap-step">
            <h3>Step 4: Understand System Design (1 Month)</h3>
            <p>For mid-level and senior roles, system design is crucial. For entry-level, a basic understanding is expected.</p>
            <p><strong>Topics to Cover:</strong></p>
            <ul>
              <li>Scalability concepts (Load Balancing, Caching, Sharding)</li>
              <li>Databases (SQL vs. NoSQL)</li>
              <li>API Design (REST, GraphQL)</li>
              <li>Designing large-scale systems (e.g., a news feed, a ride-sharing app).</li>
            </ul>
             <p><strong>Resources:</strong> "Grokking the System Design Interview" course, System Design Primer on GitHub.</p>
          </div>
          
           <div className="roadmap-step">
            <h3>Step 5: Prepare for Behavioral and Situational Questions</h3>
            <p>Google cares about your "Googliness." Be prepared to talk about your past projects, teamwork, and how you handle challenges.</p>
            <ul>
              <li><strong>STAR Method:</strong> Structure your answers using the Situation, Task, Action, Result (STAR) method.</li>
              <li><strong>Prepare Stories:</strong> Have examples ready for questions like "Tell me about a time you had a conflict with a team member" or "Describe a challenging project you worked on."</li>
            </ul>
          </div>

          <div className="roadmap-step">
            <h3>Step 6: Mock Interviews</h3>
            <p>Practice makes perfect. Conduct mock interviews with peers or on platforms like Pramp or Interviewing.io. This helps you get comfortable with coding and talking through your thought process simultaneously.</p>
          </div>

          <div className="roadmap-step">
            <h3>Step 7: Get Your Personalized Daily Tasks</h3>
            <p>Ready to start your daily practice? Click the button below to get AI-generated tasks tailored to your current progress.</p>
            <button className="ready-button" onClick={handleGenerateDailyTasks} disabled={dailyTasksState.generating}>
                {dailyTasksState.generating ? 'Generating Your Tasks...' : 'I\'m Ready! Start My Prep'}
            </button>
          </div>
          
          {dailyTasksState.tasks.length > 0 && (
            <div className="daily-tasks-container">
                <h3>Your Personalized Tasks for Today:</h3>
                {dailyTasksState.tasks.map((task, index) => (
                    <div key={index} className="daily-task-card">
                        <h4>{task.title}</h4>
                        <p><strong>Description:</strong> {task.description}</p>
                        <p><strong>Objective:</strong> {task.objective}</p>
                    </div>
                ))}
            </div>
          )}
        </section>

      </div>
    </div>
  );
}
