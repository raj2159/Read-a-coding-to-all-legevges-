module.exports = {

"[project]/src/components/icons/c-icon.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "CIcon": (()=>CIcon)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
;
function CIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "1em",
        height: "1em",
        viewBox: "0 0 24 24",
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            fill: "currentColor",
            d: "M10.033 14.39q-1.149 0-1.85-.715q-.7-.715-.7-1.89q0-1.174.7-1.89q.7-.715 1.85-.715q1.149 0 1.85.715q.7.716.7 1.89q0 1.175-.7 1.89q-.7.715-1.85.715m0-1.28q.61 0 .942-.423q.333-.423.333-1.187q0-.764-.333-1.187q-.332-.423-.942-.423q-.61 0-.942.423q-.333.423-.333 1.187q0 .764.333 1.187q.332.423.942.423"
        }, void 0, false, {
            fileName: "[project]/src/components/icons/c-icon.tsx",
            lineNumber: 12,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/icons/c-icon.tsx",
        lineNumber: 5,
        columnNumber: 5
    }, this);
}
}}),
"[project]/src/components/icons/c-plus-plus-icon.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "CPlusPlusIcon": (()=>CPlusPlusIcon)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
;
function CPlusPlusIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "1em",
        height: "1em",
        viewBox: "0 0 24 24",
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            fill: "currentColor",
            d: "M14.5 7.5a.5.5 0 0 0 0 1h1v1h-1a.5.5 0 0 0 0 1h1v1h-1a.5.5 0 0 0 0 1h1.5a.5.5 0 0 0 .5-.5v-1.5a.5.5 0 0 0-.5-.5a.5.5 0 0 0 .5-.5V8a.5.5 0 0 0-.5-.5zm3 3a.5.5 0 0 0 0 1h1v1h-1a.5.5 0 0 0 0 1h1.5a.5.5 0 0 0 .5-.5v-1.5a.5.5 0 0 0-.5-.5a.5.5 0 0 0 .5-.5v-1.5a.5.5 0 0 0-.5-.5H17.5a.5.5 0 0 0 0 1h1v1zM9.53 14.242q-.487.322-.99.322q-.732 0-1.139-.553q-.407-.553-.407-1.564V9.423h1.396v2.96q0 .67.22.952q.22.282.6.282q.21 0 .441-.094l.262-.16v1.88zM4.691 14.5q-1.149 0-1.85-.715q-.7-.715-.7-1.89q0-1.174.7-1.89q.7-.715 1.85-.715q1.149 0 1.85.715q.7.716.7 1.89q0 1.175-.7 1.89q-.7.715-1.85.715m0-1.28q.61 0 .942-.423q.333-.423.333-1.187q0-.764-.333-1.187q-.332-.423-.942-.423q-.61 0-.942.423q-.333.423-.333 1.187q0 .764.333 1.187q.332.423.942.423"
        }, void 0, false, {
            fileName: "[project]/src/components/icons/c-plus-plus-icon.tsx",
            lineNumber: 12,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/icons/c-plus-plus-icon.tsx",
        lineNumber: 5,
        columnNumber: 5
    }, this);
}
}}),
"[project]/src/components/icons/java-icon.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "JavaIcon": (()=>JavaIcon)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
;
function JavaIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "1em",
        height: "1em",
        viewBox: "0 0 24 24",
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            fill: "currentColor",
            d: "M4 21q-.825 0-1.412-.587T2 19V5q0-.825.588-1.412T4 3h16q.825 0 1.413.588T22 5v14q0 .825-.587 1.413T20 21zm4-13h6V6H8zm0 2v3q0 .825.588 1.413T10 15h2v-2h-2v-1h4v3q0 .825-.587 1.413T12 18h-2q-1.65 0-2.825-1.175T6 14v-3z"
        }, void 0, false, {
            fileName: "[project]/src/components/icons/java-icon.tsx",
            lineNumber: 12,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/icons/java-icon.tsx",
        lineNumber: 5,
        columnNumber: 5
    }, this);
}
}}),
"[project]/src/components/icons/javascript-icon.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "JavascriptIcon": (()=>JavascriptIcon)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
;
function JavascriptIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "1em",
        height: "1em",
        viewBox: "0 0 24 24",
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            fill: "currentColor",
            d: "M12 12H6v-2h6v-2H6V6h8v12h-2v-4h-2v4H6V6h2v4h4zm6-6h-4v12h4V6zm-2 10v-2h2v2zm0-4v-2h2v2zm0-4V8h2v2z"
        }, void 0, false, {
            fileName: "[project]/src/components/icons/javascript-icon.tsx",
            lineNumber: 12,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/icons/javascript-icon.tsx",
        lineNumber: 5,
        columnNumber: 5
    }, this);
}
}}),
"[project]/src/components/icons/python-icon.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "PythonIcon": (()=>PythonIcon)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
;
function PythonIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: "1em",
        height: "1em",
        viewBox: "0 0 24 24",
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            fill: "currentColor",
            d: "M21 9h-4V7a2 2 0 0 1 2-2h2zm-4 4v2h4v-2zM3 15h4v2a2 2 0 0 1-2 2H3zm4-4V9H3v2zm11-6v10a2 2 0 0 1-2 2H7v-4h4a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2H7V5a2 2 0 0 1 2-2h9z"
        }, void 0, false, {
            fileName: "[project]/src/components/icons/python-icon.tsx",
            lineNumber: 12,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/icons/python-icon.tsx",
        lineNumber: 5,
        columnNumber: 5
    }, this);
}
}}),
"[project]/src/lib/data.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "courses": (()=>courses),
    "getCourseById": (()=>getCourseById)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$icons$2f$c$2d$icon$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/icons/c-icon.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$icons$2f$c$2d$plus$2d$plus$2d$icon$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/icons/c-plus-plus-icon.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$icons$2f$java$2d$icon$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/icons/java-icon.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$icons$2f$javascript$2d$icon$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/icons/javascript-icon.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$icons$2f$python$2d$icon$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/icons/python-icon.tsx [app-ssr] (ecmascript)");
;
;
;
;
;
const courses = [
    {
        id: "html",
        title: "HTML",
        description: "Learn the foundation of web pages.",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$icons$2f$javascript$2d$icon$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["JavascriptIcon"],
        modules: [
            {
                id: "module-1",
                title: "Introduction to HTML",
                content: `
          <p>HTML (HyperText Markup Language) is the standard markup language for documents designed to be displayed in a web browser.</p>
          <p>Key concepts:</p>
          <ul>
            <li><strong>Tags:</strong> The building blocks of HTML (e.g., <code>&lt;p&gt;</code>, <code>&lt;h1&gt;</code>).</li>
            <li><strong>Elements:</strong> Consist of a start tag, content, and an end tag.</li>
            <li><strong>Attributes:</strong> Provide additional information about elements.</li>
          </ul>
        `,
                quiz: {
                    title: "HTML Quiz",
                    questions: [
                        {
                            id: "q1",
                            text: "What does HTML stand for?",
                            options: [
                                {
                                    id: "opt1",
                                    text: "HyperText Markup Language"
                                },
                                {
                                    id: "opt2",
                                    text: "Home Tool Markup Language"
                                },
                                {
                                    id: "opt3",
                                    text: "Hyperlinks and Text Markup Language"
                                }
                            ],
                            correctOptionId: "opt1"
                        }
                    ]
                }
            }
        ]
    },
    {
        id: "css",
        title: "CSS",
        description: "Style your web pages with CSS.",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$icons$2f$javascript$2d$icon$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["JavascriptIcon"],
        modules: [
            {
                id: "module-1",
                title: "Introduction to CSS",
                content: `
          <p>CSS (Cascading Style Sheets) is a style sheet language used for describing the presentation of a document written in a markup language like HTML.</p>
          <p>You'll learn about:</p>
          <ul>
            <li><strong>Selectors:</strong> To target HTML elements.</li>
            <li><strong>Properties:</strong> To style the elements (e.g., <code>color</code>, <code>font-size</code>).</li>
            <li><strong>The Box Model:</strong> Margin, border, padding, and content.</li>
          </ul>
        `,
                quiz: {
                    title: "CSS Quiz",
                    questions: [
                        {
                            id: "q1",
                            text: "Which property is used to change the background color?",
                            options: [
                                {
                                    id: "opt1",
                                    text: "color"
                                },
                                {
                                    id: "opt2",
                                    text: "background-color"
                                },
                                {
                                    id: "opt3",
                                    text: "bgcolor"
                                }
                            ],
                            correctOptionId: "opt2"
                        }
                    ]
                }
            }
        ]
    },
    {
        id: "js",
        title: "JavaScript",
        description: "Make your web pages interactive.",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$icons$2f$javascript$2d$icon$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["JavascriptIcon"],
        modules: [
            {
                id: "module-1",
                title: "Introduction to JavaScript",
                content: `
          <p>JavaScript is a programming language that enables you to create dynamically updating content, control multimedia, animate images, and much more.</p>
        `,
                quiz: {
                    title: "JavaScript Quiz",
                    questions: [
                        {
                            id: "q1",
                            text: "How do you declare a constant variable in JS?",
                            options: [
                                {
                                    id: "opt1",
                                    text: "const"
                                },
                                {
                                    id: "opt2",
                                    text: "let"
                                },
                                {
                                    id: "opt3",
                                    text: "var"
                                }
                            ],
                            correctOptionId: "opt1"
                        }
                    ]
                }
            }
        ]
    },
    {
        id: "python",
        title: "Python",
        description: "From fundamentals to advanced concepts in Python.",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$icons$2f$python$2d$icon$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["PythonIcon"],
        modules: [
            {
                id: "module-1",
                title: "Introduction to Python",
                content: `
          <p>Welcome to the world of Python! Python is a high-level, interpreted programming language known for its simple syntax and readability.</p>
          <p>In this module, you'll learn:</p>
          <ul>
            <li>What Python is and why it's so popular.</li>
            <li>How to install Python and set up your development environment.</li>
            <li>How to write and run your first Python script.</li>
          </ul>
          <pre><code class="language-python">print("Hello, World!")</code></pre>
        `,
                quiz: {
                    title: "Module 1 Quiz",
                    questions: [
                        {
                            id: "q1",
                            text: "What is Python primarily known for?",
                            options: [
                                {
                                    id: "opt1",
                                    text: "Complex syntax"
                                },
                                {
                                    id: "opt2",
                                    text: "Readability and simple syntax"
                                },
                                {
                                    id: "opt3",
                                    text: "Being a low-level language"
                                }
                            ],
                            correctOptionId: "opt2"
                        },
                        {
                            id: "q2",
                            text: "Which of the following is NOT a built-in data type in Python?",
                            options: [
                                {
                                    id: "opt1",
                                    text: "List"
                                },
                                {
                                    id: "opt2",
                                    text: "Array"
                                },
                                {
                                    id: "opt3",
                                    text: "Dictionary"
                                }
                            ],
                            correctOptionId: "opt2"
                        }
                    ]
                }
            }
        ]
    },
    {
        id: "c",
        title: "C",
        description: "Master the basics of systems programming with C.",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$icons$2f$c$2d$icon$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CIcon"],
        modules: [
            {
                id: "module-1",
                title: "C Basics",
                content: `
          <p>C is a powerful general-purpose programming language. It is fast, portable and has a rich library.</p>
        `,
                quiz: {
                    title: "C Quiz",
                    questions: [
                        {
                            id: "q1",
                            text: "Which function is used to allocate memory in C?",
                            options: [
                                {
                                    id: "opt1",
                                    text: "malloc()"
                                },
                                {
                                    id: "opt2",
                                    text: "alloc()"
                                },
                                {
                                    id: "opt3",
                                    text: "new()"
                                }
                            ],
                            correctOptionId: "opt1"
                        }
                    ]
                }
            }
        ]
    },
    {
        id: "cpp",
        title: "C++",
        description: "Explore the power and performance of C++.",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$icons$2f$c$2d$plus$2d$plus$2d$icon$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CPlusPlusIcon"],
        modules: [
            {
                id: "module-1",
                title: "C++ Basics",
                content: `
          <p>C++ is a cross-platform language that can be used to create high-performance applications.</p>
        `,
                quiz: {
                    title: "C++ Quiz",
                    questions: [
                        {
                            id: "q1",
                            text: "C++ is a superset of which language?",
                            options: [
                                {
                                    id: "opt1",
                                    text: "Python"
                                },
                                {
                                    id: "opt2",
                                    text: "C"
                                },
                                {
                                    id: "opt3",
                                    text: "Java"
                                }
                            ],
                            correctOptionId: "opt2"
                        }
                    ]
                }
            }
        ]
    },
    {
        id: "java",
        title: "Java",
        description: "Learn the fundamentals of object-oriented programming with Java.",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$icons$2f$java$2d$icon$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["JavaIcon"],
        modules: [
            {
                id: "module-1",
                title: "Java Basics",
                content: `
          <p>Java is a high-level, class-based, object-oriented programming language that is designed to have as few implementation dependencies as possible.</p>
        `,
                quiz: {
                    title: "Java Quiz",
                    questions: [
                        {
                            id: "q1",
                            text: "In Java, all classes inherit from which class?",
                            options: [
                                {
                                    id: "opt1",
                                    text: "Object"
                                },
                                {
                                    id: "opt2",
                                    text: "Class"
                                },
                                {
                                    id: "opt3",
                                    text: "Main"
                                }
                            ],
                            correctOptionId: "opt1"
                        }
                    ]
                }
            }
        ]
    }
];
const getCourseById = (id)=>{
    if (!id) return undefined;
    return courses.find((course)=>course.id === id);
};
}}),
"[project]/src/ai/flows/data:88484a [app-ssr] (ecmascript) <text/javascript>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
/* __next_internal_action_entry_do_not_use__ [{"40de6182c23b73b81e50bae67f18153bc0d4bd3726":"generateQuizQuestion"},"src/ai/flows/generate-mock-interview.ts",""] */ __turbopack_context__.s({
    "generateQuizQuestion": (()=>generateQuizQuestion)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-ssr] (ecmascript)");
"use turbopack no side effects";
;
var generateQuizQuestion = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createServerReference"])("40de6182c23b73b81e50bae67f18153bc0d4bd3726", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["findSourceMapURL"], "generateQuizQuestion"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vZ2VuZXJhdGUtbW9jay1pbnRlcnZpZXcudHMiXSwic291cmNlc0NvbnRlbnQiOlsiJ3VzZSBzZXJ2ZXInO1xuXG4vKipcbiAqIEBmaWxlT3ZlcnZpZXcgQW4gQUkgYWdlbnQgdG8gZ2VuZXJhdGUgcXVpeiBxdWVzdGlvbnMuXG4gKlxuICogLSBnZW5lcmF0ZVF1aXpRdWVzdGlvbiAtIEEgZnVuY3Rpb24gdGhhdCBnZW5lcmF0ZXMgYSBzaW5nbGUgcXVpeiBxdWVzdGlvbi5cbiAqIC0gR2VuZXJhdGVRdWl6UXVlc3Rpb25JbnB1dCAtIFRoZSBpbnB1dCB0eXBlIGZvciB0aGUgZ2VuZXJhdGVRdWl6UXVlc3Rpb24gZnVuY3Rpb24uXG4gKiAtIEdlbmVyYXRlUXVpelF1ZXN0aW9uT3V0cHV0IC0gVGhlIHJldHVybiB0eXBlIGZvciB0aGUgZ2VuZXJhdGVRdWl6UXVlc3Rpb24gZnVuY3Rpb24uXG4gKi9cblxuaW1wb3J0IHthaX0gZnJvbSAnQC9haS9nZW5raXQnO1xuaW1wb3J0IHt6fSBmcm9tICdnZW5raXQnO1xuXG5jb25zdCBHZW5lcmF0ZVF1aXpRdWVzdGlvbklucHV0U2NoZW1hID0gei5vYmplY3Qoe1xuICB0b3BpYzogei5zdHJpbmcoKS5kZXNjcmliZSgnVGhlIHRvcGljIGZvciB0aGUgcXVpeiBxdWVzdGlvbiAoZS5nLiwgRGF0YSBTdHJ1Y3R1cmVzLCBKYXZhU2NyaXB0LCBQeXRob24pLicpLFxufSk7XG5leHBvcnQgdHlwZSBHZW5lcmF0ZVF1aXpRdWVzdGlvbklucHV0ID0gei5pbmZlcjx0eXBlb2YgR2VuZXJhdGVRdWl6UXVlc3Rpb25JbnB1dFNjaGVtYT47XG5cbmNvbnN0IEdlbmVyYXRlUXVpelF1ZXN0aW9uT3V0cHV0U2NoZW1hID0gei5vYmplY3Qoe1xuICAgIGlkOiB6LnN0cmluZygpLmRlc2NyaWJlKFwiQSB1bmlxdWUgSUQgZm9yIHRoZSBxdWVzdGlvbi5cIiksXG4gICAgdGV4dDogei5zdHJpbmcoKS5kZXNjcmliZShcIlRoZSBpbnRlcnZpZXcgcXVlc3Rpb24uXCIpLFxuICAgIG9wdGlvbnM6IHouYXJyYXkoei5vYmplY3Qoe1xuICAgICAgICBpZDogei5zdHJpbmcoKS5kZXNjcmliZShcIkEgdW5pcXVlIElEIGZvciB0aGlzIG9wdGlvbi5cIiksXG4gICAgICAgIHRleHQ6IHouc3RyaW5nKCkuZGVzY3JpYmUoXCJUaGUgdGV4dCBmb3IgdGhpcyBvcHRpb24uXCIpXG4gICAgfSkpLmRlc2NyaWJlKFwiQSBsaXN0IG9mIDMtNCBtdWx0aXBsZSBjaG9pY2Ugb3B0aW9ucy5cIiksXG4gICAgY29ycmVjdE9wdGlvbklkOiB6LnN0cmluZygpLmRlc2NyaWJlKFwiVGhlIElEIG9mIHRoZSBjb3JyZWN0IG9wdGlvbi5cIiksXG59KTtcbmV4cG9ydCB0eXBlIEdlbmVyYXRlUXVpelF1ZXN0aW9uT3V0cHV0ID0gei5pbmZlcjx0eXBlb2YgR2VuZXJhdGVRdWl6UXVlc3Rpb25PdXRwdXRTY2hlbWE+O1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2VuZXJhdGVRdWl6UXVlc3Rpb24oXG4gIGlucHV0OiBHZW5lcmF0ZVF1aXpRdWVzdGlvbklucHV0XG4pOiBQcm9taXNlPEdlbmVyYXRlUXVpelF1ZXN0aW9uT3V0cHV0PiB7XG4gIHJldHVybiBnZW5lcmF0ZVF1aXpRdWVzdGlvbkZsb3coaW5wdXQpO1xufVxuXG5jb25zdCBwcm9tcHQgPSBhaS5kZWZpbmVQcm9tcHQoe1xuICBuYW1lOiAnZ2VuZXJhdGVRdWl6UXVlc3Rpb25Qcm9tcHQnLFxuICBpbnB1dDoge3NjaGVtYTogR2VuZXJhdGVRdWl6UXVlc3Rpb25JbnB1dFNjaGVtYX0sXG4gIG91dHB1dDoge3NjaGVtYTogR2VuZXJhdGVRdWl6UXVlc3Rpb25PdXRwdXRTY2hlbWF9LFxuICBwcm9tcHQ6IGBZb3UgYXJlIGFuIGV4cGVydC1sZXZlbCBpbnRlcnZpZXdlciBmb3IgYSB0b3AgdGVjaCBjb21wYW55LiBZb3VyIHJvbGUgaXMgdG8gZ2VuZXJhdGUgYSBzaW5nbGUgdGVjaG5pY2FsIHF1aXogcXVlc3Rpb24gdG8gaGVscCBhIGNhbmRpZGF0ZSBwcmVwYXJlLlxuXG4gIFRoZSBxdWVzdGlvbiBzaG91bGQgYmUgYmFzZWQgb24gdGhlIHByb3ZpZGVkIHRvcGljLiBJdCBzaG91bGQgYmUgYSBtdWx0aXBsZS1jaG9pY2UgcXVlc3Rpb24gd2l0aCAzIG9yIDQgb3B0aW9ucy4gWW91IG11c3QgcHJvdmlkZSB0aGUgY29ycmVjdCBhbnN3ZXIuIE1ha2Ugc3VyZSB0aGUgb3B0aW9ucyBhcmUgcGxhdXNpYmxlIGJ1dCBvbmx5IG9uZSBpcyBjb3JyZWN0LlxuXG4gIFRvcGljOiB7e3t0b3BpY319fVxuXG4gIEdlbmVyYXRlIG9uZSBxdWVzdGlvbi5cbiAgYCxcbn0pO1xuXG5jb25zdCBnZW5lcmF0ZVF1aXpRdWVzdGlvbkZsb3cgPSBhaS5kZWZpbmVGbG93KFxuICB7XG4gICAgbmFtZTogJ2dlbmVyYXRlUXVpelF1ZXN0aW9uRmxvdycsXG4gICAgaW5wdXRTY2hlbWE6IEdlbmVyYXRlUXVpelF1ZXN0aW9uSW5wdXRTY2hlbWEsXG4gICAgb3V0cHV0U2NoZW1hOiBHZW5lcmF0ZVF1aXpRdWVzdGlvbk91dHB1dFNjaGVtYSxcbiAgfSxcbiAgYXN5bmMgaW5wdXQgPT4ge1xuICAgIGNvbnN0IHtvdXRwdXR9ID0gYXdhaXQgcHJvbXB0KGlucHV0KTtcbiAgICByZXR1cm4gb3V0cHV0ITtcbiAgfVxuKTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoicVRBNkJzQiJ9
}}),
"[project]/src/app/page.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>UltimateSWELearningHub)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-jsx/style.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$chartjs$2d$2$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-chartjs-2/dist/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/chart.js/dist/chart.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/data.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$data$3a$88484a__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/src/ai/flows/data:88484a [app-ssr] (ecmascript) <text/javascript>");
'use client';
;
;
;
;
;
;
;
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Chart"].register(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["CategoryScale"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["LinearScale"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["BarElement"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Title"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Tooltip"], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$chart$2e$js$2f$dist$2f$chart$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Legend"]);
const pages = [
    'home',
    'html',
    'css',
    'js',
    'python',
    'c',
    'cpp',
    'java',
    'progress'
];
function UltimateSWELearningHub() {
    const [currentPage, setCurrentPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('home');
    const [progressData, setProgressData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({});
    const [isDarkMode, setIsDarkMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [quizState, setQuizState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])({});
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const savedProgress = localStorage.getItem('progressData');
        if (savedProgress) {
            setProgressData(JSON.parse(savedProgress));
        } else {
            const initialProgress = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["courses"].reduce((acc, course)=>{
                acc[course.id] = 0;
                return acc;
            }, {});
            setProgressData(initialProgress);
        }
        const initialQuizState = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["courses"].reduce((acc, course)=>{
            acc[course.id] = {
                currentQuestionIndex: 0,
                showFeedback: false,
                isCorrect: null,
                selectedOptionId: null,
                questions: course.modules[0]?.quiz?.questions ?? [],
                generatingQuestion: false
            };
            return acc;
        }, {});
        setQuizState(initialQuizState);
    }, []);
    const showPage = (page)=>{
        setCurrentPage(page);
    };
    const handleOptionSelect = (subject, optionId)=>{
        if (quizState[subject]?.showFeedback) return;
        setQuizState((prev)=>({
                ...prev,
                [subject]: {
                    ...prev[subject],
                    selectedOptionId: optionId
                }
            }));
    };
    const checkQuiz = (subject)=>{
        const state = quizState[subject];
        if (!state || state.selectedOptionId === null) return;
        const question = state.questions[state.currentQuestionIndex];
        if (!question) return;
        const correct = question.correctOptionId === state.selectedOptionId;
        setQuizState((prev)=>({
                ...prev,
                [subject]: {
                    ...prev[subject],
                    showFeedback: true,
                    isCorrect: correct
                }
            }));
        if (correct) {
            const newProgress = {
                ...progressData,
                [subject]: Math.min(progressData[subject] + 10, 100)
            };
            setProgressData(newProgress);
            localStorage.setItem('progressData', JSON.stringify(newProgress));
        }
    };
    const nextQuestion = (subject)=>{
        const state = quizState[subject];
        if (!state) return;
        const totalQuestions = state.questions.length;
        if (state.currentQuestionIndex < totalQuestions - 1) {
            setQuizState((prev)=>({
                    ...prev,
                    [subject]: {
                        ...prev[subject],
                        currentQuestionIndex: prev[subject].currentQuestionIndex + 1,
                        showFeedback: false,
                        isCorrect: null,
                        selectedOptionId: null
                    }
                }));
        } else {
            // Quiz finished or last question answered, can generate a new one
            alert(`You have completed the available questions! Generate a new one.`);
            setQuizState((prev)=>({
                    ...prev,
                    [subject]: {
                        ...prev[subject],
                        showFeedback: false,
                        isCorrect: null,
                        selectedOptionId: null
                    }
                }));
        }
    };
    const handleGenerateQuestion = async (courseId)=>{
        const course = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getCourseById"])(courseId);
        if (!course) return;
        setQuizState((prev)=>({
                ...prev,
                [courseId]: {
                    ...prev[courseId],
                    generatingQuestion: true
                }
            }));
        try {
            const newQuestion = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$ai$2f$flows$2f$data$3a$88484a__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["generateQuizQuestion"])({
                topic: course.title
            });
            setQuizState((prev)=>{
                const newQuestions = [
                    ...prev[courseId].questions,
                    newQuestion
                ];
                return {
                    ...prev,
                    [courseId]: {
                        ...prev[courseId],
                        questions: newQuestions,
                        currentQuestionIndex: newQuestions.length - 1,
                        showFeedback: false,
                        isCorrect: null,
                        selectedOptionId: null,
                        generatingQuestion: false
                    }
                };
            });
        } catch (error) {
            console.error("Failed to generate question:", error);
            alert("Sorry, we couldn't generate a new question right now. Please try again later.");
            setQuizState((prev)=>({
                    ...prev,
                    [courseId]: {
                        ...prev[courseId],
                        generatingQuestion: false
                    }
                }));
        }
    };
    const toggleMode = ()=>{
        setIsDarkMode(!isDarkMode);
        document.body.classList.toggle('dark-mode');
    };
    const chartData = {
        labels: Object.keys(progressData),
        datasets: [
            {
                label: 'Progress %',
                data: Object.values(progressData),
                backgroundColor: 'rgba(76, 175, 80, 0.5)',
                borderColor: 'rgba(76, 175, 80, 1)',
                borderWidth: 1
            }
        ]
    };
    const chartOptions = {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true,
                max: 100,
                ticks: {
                    color: isDarkMode ? '#f9f9f9' : '#222'
                },
                grid: {
                    color: isDarkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)'
                }
            },
            x: {
                ticks: {
                    color: isDarkMode ? '#f9f9f9' : '#222'
                },
                grid: {
                    color: isDarkMode ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)'
                }
            }
        },
        plugins: {
            legend: {
                labels: {
                    color: isDarkMode ? '#f9f9f9' : '#222'
                }
            }
        }
    };
    const renderQuiz = (courseId)=>{
        const course = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getCourseById"])(courseId);
        const state = quizState[courseId];
        if (!course || !state) {
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: "Loading quiz..."
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 228,
                columnNumber: 14
            }, this);
        }
        const question = state.questions[state.currentQuestionIndex];
        const renderQuestion = ()=>{
            if (!question) {
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "No questions available. Generate one!"
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 235,
                    columnNumber: 20
                }, this);
            }
            const getButtonClass = (optionId)=>{
                if (!state.showFeedback) {
                    return state.selectedOptionId === optionId ? 'selected' : '';
                }
                if (question.correctOptionId === optionId) {
                    return 'correct';
                }
                if (state.selectedOptionId === optionId) {
                    return 'incorrect';
                }
                return 'disabled';
            };
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "quiz-content",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: [
                            "Q: ",
                            question.text
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 253,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "quiz-options",
                        children: question.options.map((option)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>handleOptionSelect(courseId, option.id),
                                className: getButtonClass(option.id),
                                disabled: state.showFeedback,
                                children: option.text
                            }, option.id, false, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 256,
                                columnNumber: 25
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 254,
                        columnNumber: 17
                    }, this),
                    state.showFeedback && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `feedback ${state.isCorrect ? 'correct' : 'incorrect'}`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: state.isCorrect ? 'Correct!' : 'Incorrect. The correct answer is highlighted.'
                            }, void 0, false, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 268,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>nextQuestion(courseId),
                                children: "Next Question"
                            }, void 0, false, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 269,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 267,
                        columnNumber: 21
                    }, this),
                    !state.showFeedback && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>checkQuiz(courseId),
                        disabled: state.selectedOptionId === null,
                        children: "Check Answer"
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 273,
                        columnNumber: 21
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 252,
                columnNumber: 13
            }, this);
        };
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "quiz",
            children: [
                renderQuestion(),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "quiz-controls mt-4",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>handleGenerateQuestion(courseId),
                        disabled: state.generatingQuestion,
                        children: state.generatingQuestion ? 'Generating...' : 'Generate New Question'
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 283,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 282,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/page.tsx",
            lineNumber: 280,
            columnNumber: 7
        }, this);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "jsx-a5a841b048c717af" + " " + ((isDarkMode ? 'dark-mode' : '') || ""),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                id: "a5a841b048c717af",
                children: "*{box-sizing:border-box;margin:0;padding:0;font-family:Arial,sans-serif}body{color:#222;background:#f9f9f9;transition:background .3s,color .3s}.dark-mode{color:#f9f9f9;background:#222}.dark-mode .task,.dark-mode .module-content{color:#f1f1f1;background:#444;border-color:#555}.dark-mode .quiz button{background:#388e3c}.dark-mode .quiz button:disabled{color:#aaa;cursor:not-allowed;background:#555}.dark-mode ul{color:#f9f9f9}.dark-mode header{background:#388e3c}header{color:#fff;text-align:center;background:#4caf50;padding:10px;font-size:20px}nav{background:#333;flex-wrap:wrap;display:flex}nav button{color:#fff;cursor:pointer;background:#444;border:none;flex:1;min-width:80px;padding:10px;transition:background .2s}nav button:hover{background:#555}nav button.active{background:#4caf50}.container{padding:20px}.hidden{display:none}.chart{width:100%;height:200px}.task-list{margin-top:10px}.task{background:#ddd;border:1px solid #ccc;border-radius:5px;margin:5px 0;padding:8px}.module-content{border:1px solid #ccc;border-radius:5px;margin:10px 0;padding:15px}.module-content h3{margin-bottom:10px}.module-content pre{background:#eee;border-radius:5px;margin:10px 0;padding:10px}.dark-mode .module-content pre{background:#333}.quiz{border-top:1px solid #eee;margin-top:20px;padding:15px}.quiz p{margin-bottom:10px;font-weight:700}.quiz-options{flex-direction:column;gap:10px;margin-bottom:15px;display:flex}.quiz button,.quiz .feedback button{color:#fff;cursor:pointer;background:#4caf50;border:none;border-radius:5px;margin-top:10px;margin-right:10px;padding:8px 12px;transition:background .2s}.quiz button:disabled{cursor:not-allowed;background:#aaa}.quiz-options button{text-align:left;color:#333;background:#eee}.dark-mode .quiz-options button{color:#f1f1f1;background:#555}.quiz-options button.selected{border:2px solid #4caf50}.quiz-options button.correct{color:#fff;background:#4caf50;border-color:#388e3c}.quiz-options button.incorrect{color:#fff;background:#f44336;border-color:#d32f2f}.quiz-options button.disabled{color:#999;cursor:not-allowed;opacity:.7;border-color:#ccc}.dark-mode .quiz-options button.disabled{color:#777;border-color:#555}.feedback{border-radius:5px;margin-top:10px;padding:10px}.feedback.correct{color:#2e7d32;background-color:#e8f5e9;border:1px solid #4caf50}.feedback.incorrect{color:#c62828;background-color:#ffebee;border:1px solid #f44336}.dark-mode .feedback.correct{color:#a5d6a7;background-color:#1c3d1e}.dark-mode .feedback.incorrect{color:#ef9a9a;background-color:#4d1a1a}.toggle-mode{color:#fff;cursor:pointer;z-index:1000;background:#000;border:1px solid #fff;border-radius:6px;padding:6px;position:fixed;top:10px;right:10px}ul{color:#333;list-style-position:inside}.mt-4{margin-top:1rem}"
            }, void 0, false, void 0, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: "jsx-a5a841b048c717af",
                children: "🚀 Ultimate SWE Learning Hub"
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 338,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                onClick: toggleMode,
                className: "jsx-a5a841b048c717af" + " " + "toggle-mode",
                children: isDarkMode ? '☀️' : '🌓'
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 339,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                className: "jsx-a5a841b048c717af",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>showPage('home'),
                        className: "jsx-a5a841b048c717af" + " " + ((currentPage === 'home' ? 'active' : '') || ""),
                        children: "Home"
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 342,
                        columnNumber: 9
                    }, this),
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["courses"].map((course)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>showPage(course.id),
                            className: "jsx-a5a841b048c717af" + " " + ((currentPage === course.id ? 'active' : '') || ""),
                            children: course.title
                        }, course.id, false, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 344,
                            columnNumber: 11
                        }, this)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>showPage('progress'),
                        className: "jsx-a5a841b048c717af" + " " + ((currentPage === 'progress' ? 'active' : '') || ""),
                        children: "Progress"
                    }, void 0, false, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 348,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 341,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "jsx-a5a841b048c717af" + " " + "container",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        id: "home",
                        className: "jsx-a5a841b048c717af" + " " + ((currentPage === 'home' ? '' : 'hidden') || ""),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "jsx-a5a841b048c717af",
                                children: "Welcome to SWE Learning Hub"
                            }, void 0, false, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 353,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "jsx-a5a841b048c717af",
                                children: "Here’s what you will learn step-by-step:"
                            }, void 0, false, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 354,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                className: "jsx-a5a841b048c717af",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        className: "jsx-a5a841b048c717af",
                                        children: "✔ HTML, CSS, and Responsive Web Design"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/page.tsx",
                                        lineNumber: 356,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        className: "jsx-a5a841b048c717af",
                                        children: "✔ JavaScript and Advanced Frontend"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/page.tsx",
                                        lineNumber: 357,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        className: "jsx-a5a841b048c717af",
                                        children: "✔ Python and Data Structures"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/page.tsx",
                                        lineNumber: 358,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        className: "jsx-a5a841b048c717af",
                                        children: "✔ C, C++, and Java Programming"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/page.tsx",
                                        lineNumber: 359,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        className: "jsx-a5a841b048c717af",
                                        children: "✔ Mock Exams & Daily Tasks"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/page.tsx",
                                        lineNumber: 360,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        className: "jsx-a5a841b048c717af",
                                        children: "✔ Roadmap for Google SWE Interview"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/page.tsx",
                                        lineNumber: 361,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 355,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 352,
                        columnNumber: 9
                    }, this),
                    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["courses"].map((course)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                            id: course.id,
                            className: "jsx-a5a841b048c717af" + " " + ((currentPage === course.id ? '' : 'hidden') || ""),
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "jsx-a5a841b048c717af",
                                    children: course.title
                                }, void 0, false, {
                                    fileName: "[project]/src/app/page.tsx",
                                    lineNumber: 367,
                                    columnNumber: 13
                                }, this),
                                course.modules.map((module)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "jsx-a5a841b048c717af",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            dangerouslySetInnerHTML: {
                                                __html: `<h3>${module.title}</h3>` + module.content
                                            },
                                            className: "jsx-a5a841b048c717af" + " " + "module-content"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/page.tsx",
                                            lineNumber: 370,
                                            columnNumber: 18
                                        }, this)
                                    }, module.id, false, {
                                        fileName: "[project]/src/app/page.tsx",
                                        lineNumber: 369,
                                        columnNumber: 15
                                    }, this)),
                                renderQuiz(course.id)
                            ]
                        }, course.id, true, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 366,
                            columnNumber: 11
                        }, this)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        id: "progress",
                        className: "jsx-a5a841b048c717af" + " " + ((currentPage === 'progress' ? '' : 'hidden') || ""),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "jsx-a5a841b048c717af",
                                children: "Your Growth Chart"
                            }, void 0, false, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 378,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "jsx-a5a841b048c717af" + " " + "chart",
                                children: currentPage === 'progress' && progressData && Object.keys(progressData).length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$chartjs$2d$2$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Bar"], {
                                    data: chartData,
                                    options: chartOptions
                                }, void 0, false, {
                                    fileName: "[project]/src/app/page.tsx",
                                    lineNumber: 380,
                                    columnNumber: 100
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 379,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 377,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 351,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/page.tsx",
        lineNumber: 292,
        columnNumber: 5
    }, this);
}
}}),

};

//# sourceMappingURL=src_98ba1d66._.js.map