(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_lodash_f240f67a._.js",
  "static/chunks/node_modules_recharts_es6_f5341134._.js",
  "static/chunks/node_modules_zod_lib_index_mjs_ee760afb._.js",
  "static/chunks/node_modules_239b6011._.js",
  "static/chunks/src_1bae10e4._.js"
],
    source: "dynamic"
});
