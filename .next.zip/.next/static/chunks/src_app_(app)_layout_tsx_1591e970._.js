(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_b05f6cd6._.js",
  "static/chunks/node_modules_980daa50._.js"
],
    source: "dynamic"
});
