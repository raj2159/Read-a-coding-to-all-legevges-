(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_ebe4afc9._.js",
  "static/chunks/node_modules_0187c796._.js"
],
    source: "dynamic"
});
