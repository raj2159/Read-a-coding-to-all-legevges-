(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__e2c08166._.js",
  "static/chunks/node_modules_react_b2385d85._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_ab7e073c.js",
  "static/chunks/node_modules_react-dom_f14d0471._.js",
  "static/chunks/node_modules_3bfdc6a4._.js",
  "static/chunks/[root-of-the-server]__49fd8634._.js"
],
    source: "entry"
});
